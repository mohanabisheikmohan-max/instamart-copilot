"""
PART A - Data Preparation and EDA  (25 marks)
Goal: turn messy exports into a trusted SQLite database.
Run:  python code/part_a_eda.py
"""
from pathlib import Path
import sqlite3
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent.parent
DATA, OUT = ROOT / "data", ROOT / "outputs"
OUT.mkdir(exist_ok=True)
log = []   # everything printed is also saved to outputs/part_a_report.txt

def say(*a):
    s = " ".join(str(x) for x in a); print(s); log.append(s)

# ---------- 1. LOAD ----------
customers = pd.read_csv(DATA / "customers.csv")
orders = pd.read_csv(DATA / "orders.csv")
tickets = pd.read_csv(DATA / "support_tickets.csv")

# ---------- 2. EXPLORE: shape, dtypes, value counts with % ----------
for name, df in [("customers", customers), ("orders", orders), ("support_tickets", tickets)]:
    say(f"\n===== {name.upper()} (raw) =====")
    say("shape:", df.shape)
    say("dtypes:\n" + df.dtypes.to_string())
    say("missing:\n" + df.isna().sum().to_string())
for df, col in [(customers, "city"), (customers, "gender"), (orders, "category"), (orders, "status"), (tickets, "true_category")]:
    vc = df[col].value_counts(dropna=False)
    say(f"\nValue counts for {col} (with %):\n" + pd.DataFrame({"count": vc, "pct": (vc / len(df) * 100).round(1)}).to_string())

# ---------- 3. CLEANING RULES (each rule is documented) ----------
rules = []
n0 = len(customers); customers = customers.drop_duplicates()
rules.append(f"R1 customers: removed {n0 - len(customers)} duplicate rows")
n0 = len(orders); orders = orders.drop_duplicates()
rules.append(f"R2 orders: removed {n0 - len(orders)} duplicate rows")

CITY_MAP = {"chennai": "Chennai", "chenai": "Chennai", "madras": "Chennai",
            "bengaluru": "Bengaluru", "bangalore": "Bengaluru", "blr": "Bengaluru", "bengalore": "Bengaluru",
            "mumbai": "Mumbai", "bombay": "Mumbai", "delhi": "Delhi", "new delhi": "Delhi",
            "hyderabad": "Hyderabad", "hyderbad": "Hyderabad", "hydrabad": "Hyderabad"}
customers["city"] = customers["city"].astype(str).str.strip().str.lower().map(CITY_MAP).fillna("Unknown")
rules.append("R3 city: trim + lowercase, map spelling variants (e.g. 'bangalore','BLR' -> 'Bengaluru'); unmapped -> 'Unknown'")

GENDER_MAP = {"male": "Male", "m": "Male", "female": "Female", "f": "Female"}
customers["gender"] = customers["gender"].astype(str).str.strip().str.lower().map(GENDER_MAP).fillna("Unknown")
rules.append("R4 gender: male/m -> Male, female/f -> Female, everything else (blank, NA, Other, null) -> Unknown")

bad_age = ~customers["age"].between(16, 90)
rules.append(f"R5 age: {int(bad_age.sum())} impossible ages (<16 or >90) set to median age")
customers.loc[bad_age, "age"] = int(customers.loc[~bad_age, "age"].median())

bad_amt = (orders["order_amount"] <= 0) | (orders["order_amount"] > 20000)
rules.append(f"R6 order_amount: {int(bad_amt.sum())} rows with amount <=0 or >20000 (impossible for quick-commerce) removed")
orders = orders[~bad_amt]
bad_del = ~orders["delivery_minutes"].between(1, 180)
rules.append(f"R7 delivery_minutes: {int(bad_del.sum())} rows outside 1-180 min removed")
orders = orders[~bad_del]

q1, q3 = orders["order_amount"].quantile([.25, .75]); iqr = q3 - q1
upper = q3 + 3 * iqr
orders["is_outlier"] = (orders["order_amount"] > upper).astype(int)
rules.append(f"R8 outliers: amounts above Q3+3*IQR ({upper:.0f}) are FLAGGED (is_outlier=1) but kept")

orders = orders[orders["customer_id"].isin(customers["customer_id"])]
rules.append("R9 orders whose customer_id is not in customers are dropped (referential integrity)")
tickets["ticket_text"] = tickets["ticket_text"].fillna("")
rules.append("R10 tickets: missing text -> empty string (empty tickets are blocked later, in Part C)")

say("\n===== CLEANING RULES =====\n" + "\n".join(rules))
(OUT / "data_cleaning_rules.md").write_text("# Data cleaning rules\n\n" + "\n".join("- " + r for r in rules))

# ---------- 4. STORE IN SQLITE ----------
db = DATA / "instamart.db"
con = sqlite3.connect(db)
customers.to_sql("customers", con, if_exists="replace", index=False)
orders.to_sql("orders", con, if_exists="replace", index=False)
tickets.to_sql("support_tickets", con, if_exists="replace", index=False)

# ---------- 5. VALIDATE with Pandas AND SQL (must match) ----------
say("\n===== VALIDATION (Pandas vs SQL) =====")
checks = {
    "customers rows": (len(customers), "SELECT COUNT(*) FROM customers"),
    "orders rows": (len(orders), "SELECT COUNT(*) FROM orders"),
    "total revenue": (round(orders.order_amount.sum(), 2), "SELECT ROUND(SUM(order_amount),2) FROM orders"),
    "Chennai customers": (int((customers.city == "Chennai").sum()), "SELECT COUNT(*) FROM customers WHERE city='Chennai'"),
}
for k, (pd_val, q) in checks.items():
    sql_val = con.execute(q).fetchone()[0]
    say(f"{k:20s} pandas={pd_val}  sql={sql_val}  ->", "OK" if abs(pd_val - sql_val) < 0.01 else "MISMATCH")

say("\nRevenue by city (SQL):")
say(pd.read_sql("""SELECT c.city, COUNT(o.order_id) AS orders, ROUND(SUM(o.order_amount),0) AS revenue
                   FROM orders o JOIN customers c USING(customer_id)
                   GROUP BY c.city ORDER BY revenue DESC""", con).to_string(index=False))
dup = con.execute("SELECT COUNT(*) FROM (SELECT order_id FROM orders GROUP BY order_id HAVING COUNT(*)>1)").fetchone()[0]
say("duplicate order_ids left in DB:", dup)
con.close()

# ---------- 6. VISUALISATIONS ----------
fig, ax = plt.subplots(2, 2, figsize=(11, 8))
customers["city"].value_counts().plot.bar(ax=ax[0, 0], color="#fc8019", title="Customers per city (cleaned)")
customers["gender"].value_counts().plot.pie(ax=ax[0, 1], autopct="%1.0f%%", title="Gender (cleaned)")
orders["order_amount"].plot.hist(bins=40, ax=ax[1, 0], color="#60b246", title="Order amount distribution")
orders.groupby("category")["order_amount"].sum().sort_values().plot.barh(ax=ax[1, 1], color="#3d4152", title="Revenue by category")
for a in ax.flat: a.set_ylabel("")
plt.tight_layout(); plt.savefig(OUT / "part_a_eda.png", dpi=120); plt.close()
tickets["true_category"].value_counts().plot.bar(color="#fc8019", title="Support tickets by type")
plt.tight_layout(); plt.savefig(OUT / "part_a_tickets.png", dpi=120); plt.close()

(OUT / "part_a_report.txt").write_text("\n".join(log))
say("\nPart A finished. DB:", db)

"""
PART D (1/3) - RAG: chunking + retrieval + answer generation.
Flow:  policy documents -> CHUNKS -> TF-IDF vectors -> retrieve top-k chunks for a question -> LLM answers using ONLY those chunks.
"""
import re
import sys
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

sys.path.insert(0, str(Path(__file__).resolve().parent))
from llm import call_llm

KB = Path(__file__).resolve().parent.parent / "knowledge_base"

# ---------- CHUNKING STRATEGIES ----------
def chunk_by_heading(text: str) -> list[dict]:
    """Strategy 1: one chunk per '# Heading' section (keeps one topic together)."""
    parts = re.split(r"^# ", text, flags=re.M)
    return [{"title": p.split("\n", 1)[0].strip(), "text": p.strip()} for p in parts if p.strip()]

def chunk_by_words(text: str, size: int = 60, overlap: int = 15) -> list[dict]:
    """Strategy 2: fixed-size word windows with overlap (works on any document)."""
    words, out, step = text.split(), [], size - overlap
    for i in range(0, max(len(words) - overlap, 1), step):
        out.append({"title": f"window-{i // step}", "text": " ".join(words[i:i + size])})
    return out

class RAG:
    def __init__(self, strategy="heading"):
        raw = "\n".join(p.read_text() for p in sorted(KB.glob("*.md")))
        self.chunks = chunk_by_heading(raw) if strategy == "heading" else chunk_by_words(raw)
        self.vec = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
        self.matrix = self.vec.fit_transform([c["text"] for c in self.chunks])

    def retrieve(self, question: str, k: int = 2, min_score: float = 0.08):
        sims = cosine_similarity(self.vec.transform([question]), self.matrix)[0]
        top = sims.argsort()[::-1][:k]
        return [{**self.chunks[i], "score": round(float(sims[i]), 3)} for i in top if sims[i] >= min_score]

    def answer(self, question: str) -> dict:
        hits = self.retrieve(question)
        if not hits:
            return {"answer": "I could not find this in our policies. I will connect you to a human agent.", "sources": []}
        context = "\n\n".join(h["text"] for h in hits)
        prompt = ("You are an Instamart support co-pilot. Answer ONLY using the policy text below. "
                  "If the answer is not there, say you don't know.\n\n"
                  f"POLICY:\n{context}\n\nQUESTION: {question}\nANSWER (short, friendly):")
        fallback = hits[0]["text"].split("\n", 1)[1].strip() if "\n" in hits[0]["text"] else hits[0]["text"]
        return {"answer": call_llm(prompt, fallback=fallback), "sources": [h["title"] for h in hits]}

if __name__ == "__main__":
    r = RAG()
    print(len(r.chunks), "chunks:", [c["title"] for c in r.chunks])
    for q in ["How long does a refund take?", "My app crashed while paying", "Someone used my card"]:
        print("\nQ:", q, "\n", r.answer(q))

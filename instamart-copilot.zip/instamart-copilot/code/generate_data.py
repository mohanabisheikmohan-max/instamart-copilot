"""
generate_data.py  -  creates the SYNTHETIC Instamart datasets (messy on purpose).
NOTE: If your course gave you its own generate_data.py, replace this file with it;
every other script only needs the 3 CSVs it produces (customers, orders, support_tickets).
Run:  python code/generate_data.py
"""
import random
from pathlib import Path
import numpy as np
import pandas as pd

random.seed(42); np.random.seed(42)
DATA = Path(__file__).resolve().parent.parent / "data"
DATA.mkdir(exist_ok=True)

N_CUST, N_ORD, N_TICK = 1000, 6000, 800
CITIES = {"Chennai": ["Chennai", "chennai", "Chenai", "CHENNAI", "Madras"],
          "Bengaluru": ["Bengaluru", "bangalore", "Bangalore", "BLR", "Bengalore"],
          "Mumbai": ["Mumbai", "mumbai", "Bombay", "MUMBAI"],
          "Delhi": ["Delhi", "delhi", "New Delhi", "DELHI"],
          "Hyderabad": ["Hyderabad", "hyderbad", "Hydrabad", "hyderabad"]}
GENDERS = ["Male", "male", "M", "m", "Female", "female", "F", "f", "Other", "", "NA", None]
CATS = ["Fruits & Veg", "Dairy", "Snacks", "Beverages", "Household", "Personal Care"]

# ---------- customers ----------
cust = []
for i in range(1, N_CUST + 1):
    city = random.choice(list(CITIES))
    cust.append({"customer_id": f"C{i:05d}", "name": f"Customer {i}",
                 "email": f"user{i}@example.com", "phone": f"9{random.randint(100000000, 999999999)}",
                 "city": random.choice(CITIES[city]), "gender": random.choice(GENDERS),
                 "age": int(np.clip(np.random.normal(30, 9), 18, 70)),
                 "signup_date": (pd.Timestamp("2025-01-01") + pd.Timedelta(days=random.randint(0, 300))).date()})
customers = pd.DataFrame(cust)
customers.loc[random.sample(range(N_CUST), 6), "age"] = [150, 0, -5, 200, 999, 120]   # impossible ages
customers = pd.concat([customers, customers.sample(30, random_state=1)])              # duplicates

# ---------- orders (customers with id % 4 == 0 stopped ordering long ago = churn-like) ----------
today = pd.Timestamp("2026-10-31")
rows = []
for i in range(1, N_ORD + 1):
    cid = f"C{random.randint(1, N_CUST):05d}"
    churn_like = int(cid[1:]) % 4 == 0
    days_ago = random.randint(150, 300) if churn_like else random.randint(0, 300)
    rows.append({"order_id": f"ORD-{100000 + i}", "customer_id": cid,
                 "order_date": (today - pd.Timedelta(days=days_ago)).date(),
                 "category": random.choice(CATS),
                 "order_amount": round(float(np.random.lognormal(5.5, 0.6)), 2),
                 "delivery_minutes": int(np.clip(np.random.normal(14, 5), 5, 45)),
                 "status": random.choices(["Delivered", "Cancelled", "Refunded"], [88, 7, 5])[0]})
orders = pd.DataFrame(rows)
orders.loc[random.sample(range(N_ORD), 8), "order_amount"] = [-200, 0, 99999, 150000, -1, 500000, 75000, -50]
orders.loc[random.sample(range(N_ORD), 5), "delivery_minutes"] = [-10, 900, 1440, -1, 700]
orders = pd.concat([orders, orders.sample(120, random_state=2)])                      # duplicates

# ---------- support tickets (free text with personal data) ----------
TEMPL = {
 "refund":   ["I want a refund for order {o}, items were damaged. Mail me at {e}",
              "Please refund my money for {o}. Wrong item delivered. Call {p}",
              "Refund not received for {o}, contact {e}"],
 "fraud":    ["Unknown payment charged on my account for {o}, this looks like fraud. Phone {p}",
              "Someone used my card, order {o} is not mine. Email {e}"],
 "app_crash":["App keeps crashing when I pay for {o}", "The app crashed at checkout, order {o} stuck. {e}"],
 "late_delivery": ["Order {o} arrived 45 minutes late, very disappointed", "Delivery of {o} is very late, call me {p}"],
 "other":    ["How do I change my address? {e}", "Thanks for the quick delivery of {o}"]}
trows = []
oid_list = orders["order_id"].unique()
for i in range(1, N_TICK + 1):
    cat = random.choices(list(TEMPL), [30, 10, 15, 30, 15])[0]
    cid = f"C{random.randint(1, N_CUST):05d}"
    text = random.choice(TEMPL[cat]).format(o=random.choice(oid_list), e=f"user{int(cid[1:])}@example.com",
                                            p=f"9{random.randint(100000000, 999999999)}")
    trows.append({"ticket_id": f"T{i:05d}", "customer_id": cid,
                  "created_at": (today - pd.Timedelta(days=random.randint(0, 60))).date(),
                  "ticket_text": text, "true_category": cat})
tickets = pd.DataFrame(trows)
tickets.loc[random.sample(range(N_TICK), 10), "ticket_text"] = ""                      # empty
tickets.loc[random.sample(range(N_TICK), 10), "ticket_text"] = "     "                 # whitespace
tickets.loc[random.sample(range(N_TICK), 5), "ticket_text"] = "late delivery " * 700    # too long

customers.to_csv(DATA / "customers.csv", index=False)
orders.to_csv(DATA / "orders.csv", index=False)
tickets.to_csv(DATA / "support_tickets.csv", index=False)
print("Created:", len(customers), "customers |", len(orders), "orders |", len(tickets), "tickets ->", DATA)

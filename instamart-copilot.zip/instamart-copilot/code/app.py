"""
PART D (3/3) - Flask API that joins everything: guardrails (Part C) -> intent -> RAG or Refund agent.
Run:  python code/app.py     then open http://localhost:5000
"""
import sys
from pathlib import Path
from flask import Flask, jsonify, request, send_from_directory

sys.path.insert(0, str(Path(__file__).resolve().parent))
from part_c_guardrails import classify_ticket, validate_ticket
from rag import RAG
from refund_agent import decide_refund, find_order_id, is_refund_query, sample_orders

FRONT = Path(__file__).resolve().parent.parent / "frontend"
app = Flask(__name__, static_folder=str(FRONT), static_url_path="")
rag = RAG()

@app.get("/")
def home():
    return send_from_directory(FRONT, "index.html")

@app.get("/api/sample_orders")
def samples():
    return jsonify(sample_orders())

@app.post("/api/chat")
def chat():
    message = (request.get_json(silent=True) or {}).get("message", "")
    # 1) GUARDRAILS first - nothing reaches the model/agent if it fails
    check = validate_ticket(message)
    if not check["ok"]:
        msgs = {"EMPTY_TICKET": "Please type your question.",
                "TOO_LONG": "Your message is too long. Please shorten it to a few sentences.",
                "PII_LEFT": "I could not safely process this message."}
        return jsonify({"reply": msgs[check["reason"]], "category": None, "blocked": check["reason"]})
    # 2) classify (zero/few-shot, on the REDACTED text only)
    category = classify_ticket(message, "few_shot")["label"]
    # 3) route
    if category == "fraud":
        return jsonify({"reply": rag.answer(message)["answer"] + "\n\nI have escalated this to our fraud team.",
                        "category": category, "action": "ESCALATED_TO_FRAUD_TEAM"})
    if is_refund_query(message):
        oid = find_order_id(message)          # order id is read locally, never sent to the LLM
        if oid:
            d = decide_refund(oid)
            return jsonify({"reply": d["reason"], "category": category, "refund": d})
        is_question = message.strip().endswith("?") or message.lower().split()[0] in ("how", "what", "when", "why", "can", "is", "does")
        if not is_question:                   # a refund REQUEST without an order id -> ask for it
            return jsonify({"reply": "Sure, I can help with a refund. Please share your order id (like ORD-100123).",
                            "category": category})
    r = rag.answer(message)
    return jsonify({"reply": r["answer"], "category": category, "sources": r["sources"]})

if __name__ == "__main__":
    app.run(debug=True, port=5000)

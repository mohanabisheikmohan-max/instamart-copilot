"""
PART B - Customer Segmentation and Churn Analysis  (K-Means, unsupervised)
Idea: describe every customer with 3 numbers (RFM), group similar customers, find the group that has stopped ordering.
  Recency   = days since last order   (big = bad)
  Frequency = number of orders
  Monetary  = total money spent
Run (after part_a):  python code/part_b_segmentation.py
"""
from pathlib import Path
import sqlite3
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parent.parent
DATA, OUT = ROOT / "data", ROOT / "outputs"
con = sqlite3.connect(DATA / "instamart.db")
orders = pd.read_sql("SELECT * FROM orders WHERE status='Delivered'", con, parse_dates=["order_date"])

# ---------- 1. Build RFM table ----------
snapshot = orders["order_date"].max() + pd.Timedelta(days=1)
rfm = orders.groupby("customer_id").agg(
    recency=("order_date", lambda d: (snapshot - d.max()).days),
    frequency=("order_id", "count"),
    monetary=("order_amount", "sum")).reset_index()
print("RFM table:", rfm.shape); print(rfm.describe().round(1))

# ---------- 2. Standardise (so no column dominates) ----------
X = StandardScaler().fit_transform(rfm[["recency", "frequency", "monetary"]])

# ---------- 3. Try K = 2..8, record inertia + silhouette ----------
rows = []
for k in range(2, 9):
    km = KMeans(n_clusters=k, n_init=10, random_state=42).fit(X)
    rows.append({"k": k, "inertia": km.inertia_, "silhouette": silhouette_score(X, km.labels_)})
scores = pd.DataFrame(rows); print("\n", scores.round(3).to_string(index=False))
scores.to_csv(OUT / "part_b_k_scores.csv", index=False)

best_k = int(scores.loc[scores.silhouette.idxmax(), "k"])
print(f"\nBest K by silhouette = {best_k}")

fig, ax = plt.subplots(1, 2, figsize=(11, 4))
ax[0].plot(scores.k, scores.inertia, "o-", color="#fc8019"); ax[0].set_title("Elbow (inertia)"); ax[0].set_xlabel("K")
ax[1].plot(scores.k, scores.silhouette, "o-", color="#60b246"); ax[1].axvline(best_k, ls="--", c="grey")
ax[1].set_title("Silhouette score (higher = better)"); ax[1].set_xlabel("K")
plt.tight_layout(); plt.savefig(OUT / "part_b_k_selection.png", dpi=120); plt.close()

# ---------- 4. Final model + segment names ----------
rfm["cluster"] = KMeans(n_clusters=best_k, n_init=10, random_state=42).fit_predict(X)
prof = rfm.groupby("cluster")[["recency", "frequency", "monetary"]].mean().round(1)
prof["customers"] = rfm.groupby("cluster").size()

# Easy naming rule: highest recency (longest silence) -> "At-Risk / Churn"; best frequency+monetary -> "Champions"
names = {}
churn_cluster = prof["recency"].idxmax(); names[churn_cluster] = "At-Risk (likely churn)"
rest = prof.drop(index=churn_cluster)
names[(rest["frequency"] + rest["monetary"] / rest["monetary"].max()).idxmax()] = "Champions (loyal)"
for c in prof.index:
    names.setdefault(c, "Regular / Potential")
rfm["segment"] = rfm["cluster"].map(names)
prof["segment"] = prof.index.map(names)
print("\nCluster profile:\n", prof.to_string())

rfm["churn_risk"] = (rfm["segment"] == "At-Risk (likely churn)").astype(int)
print(f"\nCustomers likely to churn: {rfm.churn_risk.sum()} of {len(rfm)} ({rfm.churn_risk.mean()*100:.1f}%)")

# ---------- 5. Save + plot ----------
rfm.to_sql("customer_segments", con, if_exists="replace", index=False)
rfm.to_csv(OUT / "part_b_customer_segments.csv", index=False)
prof.to_csv(OUT / "part_b_cluster_profile.csv")
fig, ax = plt.subplots(1, 2, figsize=(12, 4.5))
for seg, g in rfm.groupby("segment"):
    ax[0].scatter(g.recency, g.frequency, s=12, label=seg, alpha=.7)
ax[0].set_xlabel("Recency (days since last order)"); ax[0].set_ylabel("Frequency"); ax[0].legend(); ax[0].set_title("Customer segments")
rfm["segment"].value_counts().plot.bar(ax=ax[1], color=["#fc8019", "#60b246", "#3d4152"][:rfm.segment.nunique()], title="Customers per segment")
plt.tight_layout(); plt.savefig(OUT / "part_b_segments.png", dpi=120); plt.close()
con.close()

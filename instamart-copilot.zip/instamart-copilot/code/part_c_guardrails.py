"""
PART C - Guardrails and Input Validation  (safety checks BEFORE any model call)
Rules (all documented in outputs/guardrail_rules.md):
  G1  empty / whitespace-only ticket          -> SKIP (no model call)
  G2  ticket longer than MAX_TOKENS           -> BLOCK (no model call)
  G3  personal data (email, phone, order id)  -> REDACTED before the prompt is built
  G4  prompt re-checked: if PII still found   -> BLOCK (safety net)
Also: zero-shot and few-shot prompt builders for ticket classification.
Run:  python code/part_c_guardrails.py
"""
import re
import sys
from pathlib import Path
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from llm import CATEGORIES, call_llm, offline_classify

ROOT = Path(__file__).resolve().parent.parent
DATA, OUT = ROOT / "data", ROOT / "outputs"

MAX_TOKENS = 200   # a ticket longer than ~200 tokens is not a normal complaint

EMAIL = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
PHONE = re.compile(r"(?<!\d)(?:\+?91[-\s]?)?[6-9]\d{9}(?!\d)")
ORDER = re.compile(r"\bORD-\d{4,}\b", re.IGNORECASE)

def count_tokens(text: str) -> int:
    """Rough token estimate: 1 token ~ 0.75 word  (good enough for a guardrail)."""
    return int(len(text.split()) / 0.75)

def redact_pii(text: str) -> str:
    text = EMAIL.sub("[EMAIL]", text)
    text = PHONE.sub("[PHONE]", text)
    return ORDER.sub("[ORDER_ID]", text)

def has_pii(text: str) -> bool:
    return bool(EMAIL.search(text) or PHONE.search(text) or ORDER.search(text))

def validate_ticket(text) -> dict:
    """Returns {'ok': bool, 'reason': str, 'clean_text': str}"""
    if text is None or not str(text).strip():
        return {"ok": False, "reason": "EMPTY_TICKET", "clean_text": ""}
    text = str(text).strip()
    if count_tokens(text) > MAX_TOKENS:
        return {"ok": False, "reason": "TOO_LONG", "clean_text": ""}
    clean = redact_pii(text)
    if has_pii(clean):                      # safety net
        return {"ok": False, "reason": "PII_LEFT", "clean_text": ""}
    return {"ok": True, "reason": "OK", "clean_text": clean}

# ---------- Prompt builders ----------
INSTR = f"Classify the customer support ticket into exactly one of: {', '.join(CATEGORIES)}. Reply with only the label."

def zero_shot_prompt(ticket: str) -> str:
    """ZERO-SHOT: instructions only, no examples."""
    return f"{INSTR}\n\nTicket: {ticket}\nLabel:"

FEW_SHOT_EXAMPLES = [
    ("I want my money back, the milk packet was damaged", "refund"),
    ("There is a payment on my card that I never made", "fraud"),
    ("App closes every time I press pay", "app_crash"),
    ("Groceries came one hour after the promised time", "late_delivery"),
    ("How do I change my delivery address?", "other"),
]

def few_shot_prompt(ticket: str) -> str:
    """FEW-SHOT: instructions + labelled examples, so the model copies the pattern."""
    shots = "\n".join(f"Ticket: {t}\nLabel: {l}\n" for t, l in FEW_SHOT_EXAMPLES)
    return f"{INSTR}\n\nExamples:\n{shots}\nTicket: {ticket}\nLabel:"

def classify_ticket(text, mode="few_shot") -> dict:
    """Full safe pipeline: validate -> redact -> prompt -> model."""
    v = validate_ticket(text)
    if not v["ok"]:
        return {"label": None, "model_called": False, "reason": v["reason"], "prompt": None}
    prompt = (few_shot_prompt if mode == "few_shot" else zero_shot_prompt)(v["clean_text"])
    assert not has_pii(prompt), "PII leaked into prompt!"        # hard guarantee
    raw = call_llm(prompt, fallback=offline_classify(v["clean_text"])).lower().strip()
    label = raw if raw in CATEGORIES else offline_classify(v["clean_text"])
    return {"label": label, "model_called": True, "reason": "OK", "prompt": prompt}

if __name__ == "__main__":
    tickets = pd.read_csv(DATA / "support_tickets.csv")
    results = [classify_ticket(t, "few_shot") for t in tickets["ticket_text"]]
    res = pd.DataFrame(results); res["true"] = tickets["true_category"]; res["ticket_id"] = tickets["ticket_id"]

    print("Pipeline outcome:\n", res["reason"].value_counts().to_string())
    called = res[res.model_called]
    print(f"\nModel calls made: {len(called)} / {len(res)}")
    print("Empty/whitespace/too-long tickets that reached the model:",
          int(((res.reason != 'OK') & res.model_called).sum()), "(must be 0)")
    leaks = sum(has_pii(p) for p in called["prompt"])
    print("Prompts containing personal data:", leaks, "(must be 0)")

    # compare zero-shot vs few-shot on the tickets that were allowed through
    ok_tickets = tickets[[r["model_called"] for r in results]]
    for mode in ["zero_shot", "few_shot"]:
        preds = [classify_ticket(t, mode)["label"] for t in ok_tickets["ticket_text"]]
        acc = (pd.Series(preds, index=ok_tickets.index) == ok_tickets["true_category"]).mean()
        print(f"{mode:10s} accuracy (offline model): {acc*100:.1f}%")
    print("NOTE: the offline fallback ignores the prompt, so both modes match. Set GOOGLE_API_KEY to compare them on a real LLM.")

    # show one before/after
    ex = tickets[tickets.ticket_text.str.contains("@")].iloc[0]["ticket_text"]
    print("\nBEFORE:", ex, "\nAFTER :", redact_pii(ex))
    res.drop(columns=["prompt"]).to_csv(OUT / "part_c_validation_results.csv", index=False)

    (OUT / "guardrail_rules.md").write_text(f"""# Guardrail rules (Part C)
| ID | Rule | Action |
|----|------|--------|
| G1 | Ticket is empty or only whitespace | Skip - model NOT called |
| G2 | Ticket longer than {MAX_TOKENS} tokens (est. words/0.75) | Block - model NOT called |
| G3 | Email, phone (10-digit Indian mobile), order id (ORD-xxxxxx) | Replaced with [EMAIL] [PHONE] [ORDER_ID] |
| G4 | Final prompt still contains personal data | Block (safety net) + assert |

Learning algorithms: **zero-shot** (instruction only) and **few-shot** (instruction + 5 labelled examples).
""")

"""
PART D (2/3) - Refund agent: reads the order from SQLite and applies clear, explainable rules.
The agent is NOT a black box - every decision has a reason that is shown to the customer.
"""
import re
import sqlite3
from pathlib import Path
import pandas as pd

DB = Path(__file__).resolve().parent.parent / "data" / "instamart.db"
ORDER_RE = re.compile(r"\bORD-\d{4,}\b", re.I)
REFUND_WORDS = ["refund", "money back", "damaged", "wrong item", "missing item", "spoiled"]
AUTO_LIMIT, WINDOW_DAYS = 500, 7

def is_refund_query(text: str) -> bool:
    return any(w in text.lower() for w in REFUND_WORDS)

def find_order_id(text: str):
    m = ORDER_RE.search(text)
    return m.group(0).upper() if m else None

def _reference_date(con):
    return pd.to_datetime(con.execute("SELECT MAX(order_date) FROM orders").fetchone()[0])

def decide_refund(order_id: str) -> dict:
    con = sqlite3.connect(DB)
    row = con.execute("SELECT order_id, order_date, order_amount, status, delivery_minutes FROM orders WHERE order_id=?",
                      (order_id,)).fetchone()
    if row is None:
        return {"decision": "NOT_FOUND", "reason": f"I could not find order {order_id}. Please check the order id."}
    oid, odate, amount, status, minutes = row
    age = (_reference_date(con) - pd.to_datetime(odate)).days
    info = {"order_id": oid, "amount": amount, "status": status, "days_since_order": age}
    if status == "Refunded":
        return {**info, "decision": "DENIED", "reason": "This order was already refunded."}
    if status == "Cancelled":
        return {**info, "decision": "AUTO_RETURN", "reason": "The order was cancelled, so the money returns automatically in 5-7 working days."}
    if age > WINDOW_DAYS:
        return {**info, "decision": "DENIED", "reason": f"The refund window is {WINDOW_DAYS} days and this order is {age} days old."}
    if amount <= AUTO_LIMIT:
        return {**info, "decision": "APPROVED", "reason": f"Approved: amount Rs {amount:.0f} is within the Rs {AUTO_LIMIT} auto-refund limit. Money arrives in 5-7 working days."}
    return {**info, "decision": "HUMAN_REVIEW", "reason": f"Amount Rs {amount:.0f} is above Rs {AUTO_LIMIT}, so a human agent will review it."}

def sample_orders(n=6):
    con = sqlite3.connect(DB)
    ref = _reference_date(con).strftime("%Y-%m-%d")
    df = pd.read_sql(f"""SELECT order_id, order_amount, status FROM orders
                         WHERE order_date >= date('{ref}','-{WINDOW_DAYS} day') AND status='Delivered'
                         ORDER BY RANDOM() LIMIT {n}""", con)
    return df.to_dict("records")

if __name__ == "__main__":
    for o in sample_orders(3):
        print(decide_refund(o["order_id"]))
    print(decide_refund("ORD-000000"))

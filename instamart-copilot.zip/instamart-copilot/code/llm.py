"""
llm.py - ONE place that talks to a language model.
 - If you set GOOGLE_API_KEY and installed langchain-google-genai, it uses a real LLM through LangChain.
 - Otherwise it uses a small OFFLINE keyword model, so the whole project still runs without internet or keys.
"""
import os

CATEGORIES = ["refund", "fraud", "app_crash", "late_delivery", "other"]
KEYWORDS = {"refund": ["refund", "money back", "damaged", "wrong item"],
            "fraud": ["fraud", "unknown payment", "not mine", "used my card", "unauthorized"],
            "app_crash": ["crash", "stuck", "freez", "app keeps", "not opening"],
            "late_delivery": ["late", "delay", "took too long", "not arrived", "slow"]}

def offline_classify(ticket_text: str) -> str:
    t = ticket_text.lower()
    scores = {c: sum(k in t for k in kws) for c, kws in KEYWORDS.items()}
    best = max(scores, key=scores.get)
    return best if scores[best] > 0 else "other"

def _langchain_llm():
    if not os.getenv("GOOGLE_API_KEY"):
        return None
    try:
        from langchain_google_genai import ChatGoogleGenerativeAI
        return ChatGoogleGenerativeAI(model=os.getenv("LLM_MODEL", "gemini-2.0-flash"), temperature=0)
    except Exception:
        return None

def call_llm(prompt: str, fallback: str) -> str:
    """Send prompt to the real LLM if available, else return the offline fallback answer."""
    llm = _langchain_llm()
    if llm is None:
        return fallback
    try:
        return llm.invoke(prompt).content.strip()
    except Exception:
        return fallback

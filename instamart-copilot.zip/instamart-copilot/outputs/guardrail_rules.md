# Guardrail rules (Part C)
| ID | Rule | Action |
|----|------|--------|
| G1 | Ticket is empty or only whitespace | Skip - model NOT called |
| G2 | Ticket longer than 200 tokens (est. words/0.75) | Block - model NOT called |
| G3 | Email, phone (10-digit Indian mobile), order id (ORD-xxxxxx) | Replaced with [EMAIL] [PHONE] [ORDER_ID] |
| G4 | Final prompt still contains personal data | Block (safety net) + assert |

Learning algorithms: **zero-shot** (instruction only) and **few-shot** (instruction + 5 labelled examples).

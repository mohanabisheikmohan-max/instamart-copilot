# Data cleaning rules

- R1 customers: removed 30 duplicate rows
- R2 orders: removed 120 duplicate rows
- R3 city: trim + lowercase, map spelling variants (e.g. 'bangalore','BLR' -> 'Bengaluru'); unmapped -> 'Unknown'
- R4 gender: male/m -> Male, female/f -> Female, everything else (blank, NA, Other, null) -> Unknown
- R5 age: 6 impossible ages (<16 or >90) set to median age
- R6 order_amount: 8 rows with amount <=0 or >20000 (impossible for quick-commerce) removed
- R7 delivery_minutes: 5 rows outside 1-180 min removed
- R8 outliers: amounts above Q3+3*IQR (974) are FLAGGED (is_outlier=1) but kept
- R9 orders whose customer_id is not in customers are dropped (referential integrity)
- R10 tickets: missing text -> empty string (empty tickets are blocked later, in Part C)
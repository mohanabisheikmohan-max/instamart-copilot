# Instamart Customer Intelligence and Support Co-Pilot

An end-to-end machine learning + LLM project based on a Swiggy Instamart scenario (data is **synthetic**, because real data is not available).

## 1. Problem statement
| Business problem | What this project does | Part |
|---|---|---|
| Raw exports are dirty (duplicates, mixed spellings, impossible values) | Clean data and store it in a trusted SQLite database | A |
| Retention team cannot see who will stop ordering | Group customers with K-Means; the "At-Risk" group = churn | B |
| Support desk is flooded with free-text tickets | Safe ticket classification + RAG answers + refund agent | C, D |

## 2. Project flow (each part builds on the previous one)
```
generate_data.py -> 3 CSVs --(Part A: clean)--> instamart.db --(Part B: RFM + K-Means)--> segments
support tickets --(Part C: guardrails + prompts)--> safe classification --(Part D: RAG + refund agent + React UI)--> Co-Pilot
```

## 3. Folder structure
```
data/            CSVs + instamart.db (generated)
code/            all Python code (one file per part)
knowledge_base/  policy documents used by RAG
frontend/        React chat interface (index.html)
outputs/         charts, reports, cleaning rules, guardrail rules
```

## 4. How to run
```bash
pip install -r requirements.txt
bash run_all.sh            # runs generate_data -> Part A -> B -> C
python code/app.py         # Part D, open http://localhost:5000
```
Optional real LLM: `pip install langchain langchain-google-genai`, then set `GOOGLE_API_KEY`. Without it the project uses an offline fallback, so it always runs.

## 5. Methodology
**Part A - Data prep & EDA** (`code/part_a_eda.py`): shape, dtypes, value counts with %; 10 cleaning rules (see `outputs/data_cleaning_rules.md`): duplicates, city/gender standardisation, impossible ages/amounts/delivery times, outlier flag; saved to SQLite and validated with Pandas **and** SQL (results match).

**Part B - Segmentation & churn** (`code/part_b_segmentation.py`): RFM (Recency, Frequency, Monetary) -> `StandardScaler` -> K-Means for K=2..8, record inertia + silhouette, pick best K by silhouette. The cluster with the longest silence is named **At-Risk (likely churn)**.

**Part C - Guardrails** (`code/part_c_guardrails.py`): empty/whitespace tickets skipped, over-long tickets blocked, email/phone/order id redacted before any prompt, final safety check. Zero-shot and few-shot prompt builders. Rules in `outputs/guardrail_rules.md`.

**Part D - RAG + refund agent** (`code/rag.py`, `refund_agent.py`, `app.py`, `frontend/`): two chunking strategies (by heading, by words with overlap), TF-IDF retrieval, LLM answers only from retrieved policy text. Refund agent rules: 7-day window, auto-approve up to Rs 500, above that human review, cancelled/refunded handled. React chat UI.

## 6. Results
| Part | Result |
|---|---|
| A | 1030->1000 customers, 6120->5987 orders after cleaning; Pandas = SQL on all checks |
| B | Best K = 3 (silhouette 0.37): Champions, Regular, At-Risk (~29% of customers likely to churn) |
| C | 785/800 tickets pass; 15 empty/too-long tickets never reach the model; 0 prompts contain personal data |
| D | Policy questions answered from the knowledge base; refunds decided with an explanation |

## 7. Limitations (honest notes)
- Data is synthetic, so numbers are illustrative.
- Zero-shot vs few-shot accuracy can only be compared with a real LLM; the offline fallback ignores the prompt.
- TF-IDF retrieval is simple; embeddings would be the next upgrade.

## 8. Why GitHub matters
Version control, professional documentation, change history, portfolio proof. Branches: `part-a-eda`, `part-b-segmentation`, `part-c-guardrails`, `part-d-rag-refund` (create with `bash setup_github.sh`).

#!/usr/bin/env bash
# Runs Parts A -> C in order. Then start the app with: python code/app.py
set -e
python code/generate_data.py
python code/part_a_eda.py > /dev/null && echo "Part A done"
python code/part_b_segmentation.py > outputs/part_b_report.txt && echo "Part B done"
python code/part_c_guardrails.py > outputs/part_c_report.txt && echo "Part C done"
echo "Now run:  python code/app.py   (Part D) and open http://localhost:5000"

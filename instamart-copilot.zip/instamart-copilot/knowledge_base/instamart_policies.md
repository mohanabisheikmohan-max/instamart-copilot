# Refund Policy
Customers can request a refund within 7 days of the order date. Refunds are allowed for damaged items, wrong items, missing items and spoiled products.
Orders with amount up to 500 rupees are approved automatically. Orders above 500 rupees are sent to a human support agent for review.
Refunds are credited to the original payment method within 5 to 7 working days. Instamart wallet refunds are instant.

# Cancelled Orders
If an order is cancelled before delivery, the full amount is returned automatically to the original payment method in 5 to 7 working days. No request is needed.

# Late Delivery Policy
Instamart promises delivery in about 10 to 20 minutes. If delivery takes more than 30 minutes, the customer is eligible for a delay coupon worth 50 rupees. Customers should share the order id to claim it.

# Fraud and Unknown Payments
If you see a payment you did not make, do not share OTP or card details with anyone. Report the order id. The ticket goes to the fraud team immediately and the card payment is put on hold while the case is investigated.

# App Problems
If the app crashes or the payment gets stuck, update the app to the latest version, clear the cache and try again. If money was deducted but the order was not placed, it is returned automatically in 5 to 7 working days.

# Account and Address
You can change your delivery address from Profile, then Addresses, before placing the order. Addresses cannot be changed after the order is out for delivery.

# Privacy
Support agents never ask for your OTP, full card number or password.

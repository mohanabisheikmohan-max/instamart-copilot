#!/usr/bin/env bash
# Creates one repo with the 4 required branches. Edit YOUR_REPO_URL first.
set -e
git init -b main
printf "__pycache__/\n*.pyc\n.env\n" > .gitignore
git add . && git commit -m "Initial project: README, data, code, outputs"
for part in part-a-eda part-b-segmentation part-c-guardrails part-d-rag-refund; do
  git branch "$part"
done
# git remote add origin YOUR_REPO_URL
# git push -u origin --all
